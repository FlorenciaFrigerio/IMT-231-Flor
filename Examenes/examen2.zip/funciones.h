#ifndef FUNCIONES_H
#define FUNCIONES_H


int esPrimo(int n);
int factorial(int n);
void contarParesImpares(int n);
void mostrarMultiplosDe3(int n);

#endif
