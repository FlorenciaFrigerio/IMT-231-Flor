from . import divisores, triangulo_letras, primos, fibonacci_inverso
